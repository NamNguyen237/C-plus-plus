#include<bits/stdc++.h>
#include "vector.h"
using namespace std;

Vector::Vector(){ //vector co chieu = 5
    n = 5;
    a = new float[n];
    for (int i = 0; i < n; i++)
        a[i] = 0;
}
Vector::Vector(int k){ //vector co chieu = k
    n = k;
    a = new float[n];
    for (int i = 0; i < n; i++)
        a[i] = 0;
}
Vector::Vector(const Vector &v)
{
    //HTL sao chep
    n = v.n; //n: so chieu cua vector dang dc tao ra
    a = new float[n];
    for (int i = 0; i<n; i++)
        a[i] = v.a[i];
}
void Vector::Nhap(char *s){
    cout << "\nNhap " << n << " so thuc cho vector " << s <<": ";
    for(int i = 0; i < n; i++){
        cin >> a[i];
    }
}

void Vector::Hienthi(char *s){
    cout << "\n" << s;
    for(int i = 0; i < n; i++){
        cout << a[i] << " ";
    }
    cout << endl;
}
Vector::~Vector(){
    delete(a);
}
float Vector::Tinhchuan(){
    float tongbinhphuong = 0;
    for(int i = 0; i < n; i++){
        tongbinhphuong += a[i] * a[i];
    }
    return sqrt(tongbinhphuong);
}
Vector Vector::operator+(const Vector &v) //cong
{
    if (n == v.n)
    {
        Vector kq(n);
        for (int i = 0; i < n; i++)
            kq.a[i] = a[i] + v.a[i];

        return kq;
    }
    else
        return Vector(0);
}

Vector Vector::operator-(const Vector &v){ //tru
    Vector temp;
    temp.n = n;
    temp.a = new float[n];
    for(int i = 0; i < n; i++){
        temp.a[i] = a[i] - v.a[i];
    }
    return temp;
}

Vector Vector::operator*(const Vector &v){ //tich vo huong (vector nhan vector)
    Vector temp;
    temp.n = n;
    temp.a = new float[n];
    for(int i = 0; i < n; i++){
        temp.a[i] = a[i] * v.a[i];
    }
    return temp;
}

Vector Vector::operator*(float x){ //nhan so thuc
    Vector temp;
    temp.n = n;
    temp.a = new float[n];
    for(int i = 0; i < n; i++){
        temp.a[i] = a[i] * x;
    }
    return temp;
}


